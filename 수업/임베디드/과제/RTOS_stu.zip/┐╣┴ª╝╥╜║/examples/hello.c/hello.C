#include "includes.h"

#define  TASK_STK_SIZE                 512       /* Size of each task's stacks (# of WORDs)            */

OS_STK        TaskStk[TASK_STK_SIZE];        /* Tasks stacks                                  */

void  TaskStart(void *data);                  /* Function prototypes of Startup task           */

int  main (void)
{
    OSInit();                                              /* Initialize uC/OS-II                      */
    OSTaskCreate(TaskStart, (void *)0, &TaskStk[TASK_STK_SIZE - 1], 1);
    OSStart();                                             /* Start multitasking                       */
    return 0;
}


void  TaskStart (void *pdata)
{
	printf("test\n");
}

